import React, { useState } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
    import { CheckCircle, Star, Zap, ShieldCheck, Users, HelpCircle as HelpIcon } from 'lucide-react';
    import { Switch } from '@/components/ui/switch';
    import { Label } from '@/components/ui/label';
    import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';


    const pricingTiers = {
      monthly: [
        {
          name: "Pioneer",
          price: "$19",
          frequency: "/month",
          features: [
            "1 Digital Twin",
            "Basic AI Learning Modules",
            "Limited NFT Minting (1 per month)",
            "Community Forum Access",
            "Standard Security",
          ],
          cta: "Start Pioneering",
          color: "purple",
          popular: false,
        },
        {
          name: "Explorer",
          price: "$49",
          frequency: "/month",
          features: [
            "Up to 3 Digital Twins",
            "All AI Learning Modules",
            "Standard NFT Minting (5 per month)",
            "Priority Community Access",
            "Enhanced Security Features",
            "Early Access to New Features",
          ],
          cta: "Become an Explorer",
          color: "pink",
          popular: true,
        },
        {
          name: "Visionary",
          price: "$99",
          frequency: "/month",
          features: [
            "Unlimited Digital Twins",
            "Advanced AI Customization Tools",
            "Unlimited NFT Minting & Marketplace Access",
            "Dedicated Support Channel",
            "Premium Security & ZKP Options",
            "API Access for Developers",
          ],
          cta: "Shape the Future",
          color: "teal",
          popular: false,
        },
      ],
      annually: [
        {
          name: "Pioneer Annual",
          price: "$190",
          frequency: "/year",
          features: [
            "1 Digital Twin",
            "Basic AI Learning Modules",
            "Limited NFT Minting (1 per month)",
            "Community Forum Access",
            "Standard Security",
            "2 Months Free!",
          ],
          cta: "Start Pioneering (Annual)",
          color: "purple",
          popular: false,
        },
        {
          name: "Explorer Annual",
          price: "$490",
          frequency: "/year",
          features: [
            "Up to 3 Digital Twins",
            "All AI Learning Modules",
            "Standard NFT Minting (5 per month)",
            "Priority Community Access",
            "Enhanced Security Features",
            "Early Access to New Features",
            "2 Months Free!",
          ],
          cta: "Become an Explorer (Annual)",
          color: "pink",
          popular: true,
        },
        {
          name: "Visionary Annual",
          price: "$990",
          frequency: "/year",
          features: [
            "Unlimited Digital Twins",
            "Advanced AI Customization Tools",
            "Unlimited NFT Minting & Marketplace Access",
            "Dedicated Support Channel",
            "Premium Security & ZKP Options",
            "API Access for Developers",
            "2 Months Free!",
          ],
          cta: "Shape the Future (Annual)",
          color: "teal",
          popular: false,
        },
      ],
    };

    const featureIcons = {
        "Digital Twin": <Users size={16} className="mr-2 text-gray-400" />,
        "AI Learning": <Zap size={16} className="mr-2 text-gray-400" />,
        "NFT Minting": <Star size={16} className="mr-2 text-gray-400" />,
        "Community": <Users size={16} className="mr-2 text-gray-400" />,
        "Security": <ShieldCheck size={16} className="mr-2 text-gray-400" />,
        "Support": <HelpIcon size={16} className="mr-2 text-gray-400" />,
        "API Access": <Zap size={16} className="mr-2 text-gray-400" />,
        "Early Access": <Star size={16} className="mr-2 text-gray-400" />,
        "Months Free": <Star size={16} className="mr-2 text-yellow-400" />,
    };

    const getFeatureIcon = (featureText) => {
        for (const key in featureIcons) {
            if (featureText.toLowerCase().includes(key.toLowerCase())) {
                return featureIcons[key];
            }
        }
        return <CheckCircle size={16} className="mr-2 text-green-400" />;
    };


    const PricingPage = () => {
      const [billingCycle, setBillingCycle] = useState('monthly');
      const currentTiers = pricingTiers[billingCycle];

      const handleStripeCheckout = (priceId) => {
        // Placeholder for Stripe integration
        // In a real app, you'd redirect to Stripe Checkout here
        alert(`Redirecting to Stripe for price ID: ${priceId} (Not Implemented)`);
      };


      return (
        <div className="container mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <h1 className="text-5xl md:text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500">
              Flexible Pricing Plans
            </h1>
            <p className="text-xl text-purple-200 max-w-2xl mx-auto">
              Choose the perfect plan to unlock the full potential of your digital legacy. Get started for free, upgrade anytime.
            </p>
          </motion.div>

          <motion.div 
            className="flex justify-center items-center space-x-3 mb-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Label htmlFor="billing-cycle" className={`text-lg font-medium ${billingCycle === 'monthly' ? 'text-primary' : 'text-muted-foreground'}`}>Monthly</Label>
            <Switch 
              id="billing-cycle" 
              checked={billingCycle === 'annually'}
              onCheckedChange={(checked) => setBillingCycle(checked ? 'annually' : 'monthly')}
              className="data-[state=checked]:bg-primary"
            />
            <Label htmlFor="billing-cycle" className={`text-lg font-medium ${billingCycle === 'annually' ? 'text-primary' : 'text-muted-foreground'}`}>Annually</Label>
            {billingCycle === 'annually' && <span className="ml-2 px-2 py-1 text-xs font-semibold bg-green-500/20 text-green-300 rounded-full">Save 2 Months!</span>}
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {currentTiers.map((tier, index) => (
              <motion.div
                key={tier.name}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.1 * index + 0.3 }}
              >
                <Card className={`flex flex-col h-full bg-card/80 backdrop-blur-md border-${tier.color}-500/30 shadow-xl hover:shadow-${tier.color}-500/40 transition-all duration-300 ${tier.popular ? 'border-2 border-' + tier.color + '-500 scale-105 relative' : ''}`}>
                  {tier.popular && (
                    <div className={`absolute -top-3 -right-3 bg-${tier.color}-500 text-white text-xs font-semibold px-3 py-1 rounded-full shadow-md transform rotate-6`}>
                      POPULAR
                    </div>
                  )}
                  <CardHeader className="text-center pb-4">
                    <Star size={32} className={`mx-auto mb-2 text-${tier.color}-400`} />
                    <CardTitle className={`text-3xl font-bold text-${tier.color}-300`}>{tier.name}</CardTitle>
                    <CardDescription className="text-muted-foreground">
                      <span className={`text-4xl font-extrabold text-${tier.color}-200`}>{tier.price}</span>
                      <span className="text-sm text-muted-foreground">{tier.frequency}</span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <ul className="space-y-3">
                      {tier.features.map((feature, i) => (
                        <li key={i} className="flex items-center text-gray-300">
                          {getFeatureIcon(feature)}
                          <span>{feature}</span>
                          {feature.includes("NFT Minting") && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <HelpIcon size={14} className="ml-1 text-muted-foreground cursor-help" />
                              </TooltipTrigger>
                              <TooltipContent className="bg-background text-foreground border-primary">
                                <p>NFTs (Non-Fungible Tokens) represent unique digital assets on the blockchain.</p>
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className={`w-full bg-gradient-to-r from-${tier.color}-500 to-${tier.color}-600 hover:from-${tier.color}-600 hover:to-${tier.color}-700 text-white font-semibold shadow-lg transform hover:scale-105 transition-all duration-300`}
                      onClick={() => handleStripeCheckout(`price_id_for_${tier.name.toLowerCase().replace(' ', '_')}_${billingCycle}`)}
                    >
                      {tier.cta}
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </div>
          
          <motion.div 
            className="mt-16 p-8 bg-card/70 backdrop-blur-md rounded-xl border border-purple-500/20 shadow-2xl text-center"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.8 }}
          >
            <h2 className="text-3xl font-bold text-primary-foreground mb-4">Enterprise Solutions</h2>
            <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
              Need a custom solution for your university, research institution, or large organization? We offer tailored packages with dedicated infrastructure, advanced AI model training, and full data sovereignty.
            </p>
            <Button variant="outline" size="lg" className="text-purple-300 border-purple-400 hover:bg-purple-400 hover:text-slate-900 transition-colors duration-300">
              Contact Sales
            </Button>
          </motion.div>

          <motion.div 
            className="mt-12 text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.0 }}
          >
            <img  
              alt="Abstract representation of data flowing into a secure vault, symbolizing value and investment" 
              className="w-full max-w-2xl mx-auto rounded-lg shadow-xl opacity-70"
             src="https://images.unsplash.com/photo-1654588836190-d8e6c12122f8" />
          </motion.div>

        </div>
      );
    };

    export default PricingPage;