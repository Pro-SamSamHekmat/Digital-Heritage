import React, { useState } from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
    import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
    import { useToast } from '@/components/ui/use-toast';
    import { useNavigate } from 'react-router-dom';
    import { Mail, Lock, UserPlus, LogIn as LogInIcon, ExternalLink } from 'lucide-react';
    import { FaGoogle, FaFacebook, FaTwitter, FaWallet } from 'react-icons/fa';


    const LoginPage = ({ setIsLoggedIn }) => {
      const { toast } = useToast();
      const navigate = useNavigate();
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
      const [confirmPassword, setConfirmPassword] = useState('');
      const [name, setName] = useState('');

      const handleLogin = (e) => {
        e.preventDefault();
        if (!email || !password) {
          toast({ title: "Error", description: "Please enter email and password.", variant: "destructive" });
          return;
        }
        // Placeholder login logic
        console.log("Logging in with:", email, password);
        toast({ title: "Success", description: "Logged in successfully!" });
        setIsLoggedIn(true);
        navigate('/dashboard');
      };

      const handleRegister = (e) => {
        e.preventDefault();
        if (!name || !email || !password || !confirmPassword) {
          toast({ title: "Error", description: "Please fill all fields.", variant: "destructive" });
          return;
        }
        if (password !== confirmPassword) {
          toast({ title: "Error", description: "Passwords do not match.", variant: "destructive" });
          return;
        }
        // Placeholder registration logic
        console.log("Registering:", name, email, password);
        toast({ title: "Success", description: "Registered successfully! Please log in." });
        // Switch to login tab or redirect, for now just a toast
      };
      
      const handleSocialLogin = (provider) => {
        toast({ title: "Social Login", description: `Attempting to log in with ${provider}... (Not Implemented)`});
        // Placeholder for social login logic
        // Potentially setIsLoggedIn(true) and navigate('/dashboard') after successful auth
      };

      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-800">
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Card className="w-full max-w-md bg-card/80 backdrop-blur-lg border-purple-500/30 shadow-2xl shadow-purple-500/20">
              <CardHeader className="text-center">
                <motion.div 
                  className="inline-block p-3 bg-primary/10 rounded-full mb-4"
                  animate={{ scale: [1, 1.1, 1], rotate: [0, 5, -5, 0] }}
                  transition={{ repeat: Infinity, duration: 3 }}
                >
                  <LogInIcon className="h-10 w-10 text-primary" />
                </motion.div>
                <CardTitle className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                  Welcome Back
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  Access your Digital Heritage account or create a new one.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="login" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-secondary/30">
                    <TabsTrigger value="login" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Login</TabsTrigger>
                    <TabsTrigger value="register" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">Register</TabsTrigger>
                  </TabsList>
                  <TabsContent value="login">
                    <form onSubmit={handleLogin} className="space-y-6 mt-6">
                      <div className="space-y-2">
                        <Label htmlFor="login-email">Email</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                          <Input id="login-email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required className="pl-10" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="login-password">Password</Label>
                         <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                          <Input id="login-password" type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} required className="pl-10" />
                        </div>
                      </div>
                      <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold shadow-lg">
                        <LogInIcon className="mr-2 h-5 w-5" /> Login
                      </Button>
                    </form>
                  </TabsContent>
                  <TabsContent value="register">
                    <form onSubmit={handleRegister} className="space-y-6 mt-6">
                      <div className="space-y-2">
                        <Label htmlFor="register-name">Full Name</Label>
                        <Input id="register-name" type="text" placeholder="Your Name" value={name} onChange={(e) => setName(e.target.value)} required />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-email">Email</Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                          <Input id="register-email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required className="pl-10" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-password">Password</Label>
                        <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                          <Input id="register-password" type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} required className="pl-10" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="confirm-password">Confirm Password</Label>
                         <div className="relative">
                          <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                          <Input id="confirm-password" type="password" placeholder="••••••••" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required className="pl-10" />
                        </div>
                      </div>
                      <Button type="submit" className="w-full bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white font-semibold shadow-lg">
                        <UserPlus className="mr-2 h-5 w-5" /> Register
                      </Button>
                    </form>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="flex flex-col space-y-4">
                <div className="relative w-full my-4">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-muted-foreground/50" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 w-full">
                   <Button variant="outline" className="w-full border-red-500 text-red-400 hover:bg-red-500/10 hover:text-red-300" onClick={() => handleSocialLogin('Google')}>
                    <FaGoogle className="mr-2 h-5 w-5" /> Google
                  </Button>
                  <Button variant="outline" className="w-full border-blue-600 text-blue-500 hover:bg-blue-600/10 hover:text-blue-400" onClick={() => handleSocialLogin('Facebook')}>
                    <FaFacebook className="mr-2 h-5 w-5" /> Facebook
                  </Button>
                  <Button variant="outline" className="w-full border-sky-500 text-sky-400 hover:bg-sky-500/10 hover:text-sky-300" onClick={() => handleSocialLogin('Twitter')}>
                    <FaTwitter className="mr-2 h-5 w-5" /> X (Twitter)
                  </Button>
                  <Button variant="outline" className="w-full border-purple-500 text-purple-400 hover:bg-purple-500/10 hover:text-purple-300" onClick={() => handleSocialLogin('Wallet')}>
                    <FaWallet className="mr-2 h-5 w-5" /> Wallet
                  </Button>
                </div>
                <p className="px-8 text-center text-sm text-muted-foreground mt-4">
                  By clicking continue, you agree to our{" "}
                  <a href="/terms" className="underline underline-offset-4 hover:text-primary">
                    Terms of Service
                  </a>{" "}
                  and{" "}
                  <a href="/privacy" className="underline underline-offset-4 hover:text-primary">
                    Privacy Policy
                  </a>
                  .
                </p>
              </CardFooter>
            </Card>
          </motion.div>
        </div>
      );
    };

    export default LoginPage;