import React from 'react';
    import { motion } from 'framer-motion';
    import { Users, Zap, Target, Eye, HeartHandshake, Cpu, Milestone, Award, ShieldCheck } from 'lucide-react';
    import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
    import { Button } from '@/components/ui/button';

    const teamMembers = [
      { name: "Dr. Evelyn Reed", role: "Founder & AI Visionary", imageName: "Portrait of Dr. Evelyn Reed, AI researcher", initials: "ER" },
      { name: "Marcus Chen", role: "Lead Blockchain Architect", imageName: "Portrait of Marcus Chen, blockchain developer", initials: "MC" },
      { name: "Aisha Khan", role: "Head of User Experience", imageName: "Portrait of Aisha Khan, UX designer", initials: "AK" },
      { name: "Dr. Samuel Green", role: "Ethics & Privacy Officer", imageName: "Portrait of Dr. Samuel Green, ethics specialist", initials: "SG" },
    ];

    const AboutPage = () => {
      return (
        <div className="container mx-auto px-4 py-16">
          <motion.section
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-sky-400 via-cyan-500 to-blue-500">
              About Digital Heritage
            </h1>
            <p className="text-xl text-purple-200 max-w-3xl mx-auto">
              We are a passionate team of innovators, technologists, and humanists dedicated to revolutionizing how we preserve memories, share knowledge, and connect with one another.
            </p>
          </motion.section>

          <motion.section 
            className="mb-16 grid md:grid-cols-2 gap-12 items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div>
              <h2 className="text-4xl font-bold mb-6 text-primary-foreground">Our Mission <Target className="inline-block ml-2 text-primary" /></h2>
              <p className="text-lg text-gray-300 leading-relaxed mb-4">
                “Preserving memories, expanding knowledge and empowering human connections through new technologies.”
              </p>
              <p className="text-lg text-gray-300 leading-relaxed">
                At Digital Heritage, we believe that technology should serve humanity's deepest needs: the need to remember, to learn, and to connect. We are building a future where personal legacies are not lost to time, where knowledge is universally accessible and personalized, and where human bonds can transcend physical limitations.
              </p>
            </div>
            <div>
              <img  
                alt="Diverse team collaborating around a futuristic holographic display" 
                className="w-full h-auto rounded-xl shadow-2xl object-cover"
               src="https://images.unsplash.com/photo-1675023071165-605910db8925" />
            </div>
          </motion.section>

          <motion.section 
            className="mb-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, staggerChildren: 0.2 }}
          >
            <h2 className="text-4xl font-bold text-center mb-12 text-primary-foreground">Our Core Values <HeartHandshake className="inline-block ml-2 text-primary" /></h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { icon: <Eye size={32} />, title: "Innovation", description: "Pushing the boundaries of AI and decentralized tech." },
                { icon: <Users size={32} />, title: "Human-Centricity", description: "Designing for emotional resonance and user empowerment." },
                { icon: <ShieldCheck size={32} />, title: "Trust & Security", description: "Prioritizing privacy and data sovereignty above all." },
                { icon: <Zap size={32} />, title: "Accessibility", description: "Making advanced technology inclusive and easy to use." },
              ].map((value, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="text-center bg-card/70 backdrop-blur-md border-purple-500/20 shadow-lg hover:shadow-primary/20 transition-shadow h-full">
                    <CardHeader>
                      <div className="p-3 bg-primary/10 rounded-full w-16 h-16 mx-auto flex items-center justify-center mb-3 text-primary">
                        {value.icon}
                      </div>
                      <CardTitle className="text-xl text-primary-foreground">{value.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">{value.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.section>

          <motion.section 
            className="mb-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, staggerChildren: 0.2 }}
          >
            <h2 className="text-4xl font-bold text-center mb-12 text-primary-foreground">Meet Our Team <Cpu className="inline-block ml-2 text-primary" /></h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {teamMembers.map((member, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="text-center bg-card/70 backdrop-blur-md border-purple-500/20 shadow-lg hover:shadow-primary/20 transition-shadow h-full p-6">
                    <Avatar className="w-24 h-24 mx-auto mb-4 border-4 border-primary/50">
                      <AvatarImage asChild>
                        <img  src={`/team/${member.name.toLowerCase().replace(' ', '-')}.jpg`} alt={member.name} src="https://images.unsplash.com/photo-1694388001616-1176f534d72f" />
                      </AvatarImage>
                      <AvatarFallback className="bg-primary/20 text-primary text-3xl">{member.initials}</AvatarFallback>
                    </Avatar>
                    <h3 className="text-xl font-semibold text-primary-foreground">{member.name}</h3>
                    <p className="text-primary">{member.role}</p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.section>
          
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="text-center mt-16 p-8 bg-gradient-to-r from-purple-600/30 via-pink-600/30 to-red-600/30 rounded-xl shadow-2xl"
          >
            <h2 className="text-3xl font-bold text-white mb-4">Join Us on Our Journey</h2>
            <p className="text-purple-200 mb-6 max-w-xl mx-auto">
              We're always looking for talented individuals passionate about the intersection of technology and humanity. Check our careers page or get in touch to learn more.
            </p>
            <Button variant="outline" className="bg-transparent border-white text-white hover:bg-white hover:text-slate-900 transition-colors">
              View Careers (Coming Soon)
            </Button>
          </motion.section>
        </div>
      );
    };

    export default AboutPage;