import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { Link } from 'react-router-dom';
    import { Brain, Lightbulb, Lock, Users, ShieldCheck, ArrowRight, Zap, MessageSquare, Palette, BookOpen } from 'lucide-react';

    const serviceItems = [
      {
        icon: <Brain size={40} className="text-purple-400" />,
        title: "Intelligent Digital Twin Creation",
        description: "Craft lifelike digital avatars of yourself or loved ones. These twins learn, adapt, and can simulate personalities based on provided data, preserving memories and personas.",
        details: [
          "Personality modeling from text, audio, and video.",
          "Voice synthesis and cloning (with consent).",
          "Continuous learning and adaptation based on interactions.",
          "Secure data vaults for personal information."
        ],
        imageName: "Digital twin creation interface with neural network visualization"
      },
      {
        icon: <Lightbulb size={40} className="text-pink-400" />,
        title: "Multidimensional Specialized Learning",
        description: "Access AI-powered tutors and assistants across diverse fields. Engage in natural conversations and receive expert guidance tailored to your learning style.",
        details: [
          "Basic Sciences (Physics, Mathematics, Biology).",
          "Philosophy & Art Analysis (Literary criticism, art history).",
          "Foreign Language Tutoring (Conversational practice, accent coaching).",
          "Personalized learning paths and progress tracking."
        ],
        imageName: "Student interacting with AI tutor on a futuristic tablet"
      },
      {
        icon: <Lock size={40} className="text-teal-400" />,
        title: "NFT-Based Digital Identity & Ownership",
        description: "Securely own and manage your AI models and data as NFTs. This enables true digital ownership, with options to trade, lease, or bequeath your digital assets.",
        details: [
          "Mint AI models and datasets as unique NFTs.",
          "Decentralized marketplace for AI assets.",
          "Smart contract-based licensing and royalty distribution.",
          "Verifiable ownership on the blockchain."
        ],
        imageName: "Glowing NFT representing an AI model on a blockchain network"
      },
      {
        icon: <Users size={40} className="text-yellow-400" />,
        title: "Secure Interactive Community",
        description: "Connect with like-minded individuals and experts in a secure environment. Participate in AI-augmented forums, virtual events, and collaborative projects.",
        details: [
          "Expert forums with AI-assisted moderation and insights.",
          "Virtual concerts, art exhibitions, and conferences.",
          "Anonymous consultation channels with verified professionals.",
          "Collaborative knowledge-building platforms."
        ],
        imageName: "Diverse group of avatars interacting in a virtual event space"
      },
       {
        icon: <ShieldCheck size={40} className="text-green-400" />,
        title: "Advanced Privacy & Security",
        description: "Your data's integrity and privacy are paramount. We employ cutting-edge technologies to ensure your digital heritage is protected and under your full control.",
        details: [
          "Decentralized data storage (IPFS & Blockchain options).",
          "Zero-Knowledge Proofs for privacy-preserving interactions.",
          "End-to-end encryption for all communications.",
          "Granular user control over data access and deletion."
        ],
        imageName: "Abstract representation of data security shield with encryption patterns"
      }
    ];

    const ServicesPage = () => {
      return (
        <div className="container mx-auto px-4 py-16">
          <motion.div
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-16"
          >
            <h1 className="text-5xl md:text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">
              Our Services
            </h1>
            <p className="text-xl text-purple-200 max-w-2xl mx-auto">
              Explore the innovative ways Digital Heritage empowers you to preserve memories, expand knowledge, and connect in new dimensions.
            </p>
          </motion.div>

          <div className="space-y-12">
            {serviceItems.map((service, index) => (
              <motion.section
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.6, delay: 0.1 * index }}
                className={`flex flex-col md:flex-row items-center gap-8 md:gap-12 p-6 md:p-8 rounded-xl bg-card/70 backdrop-blur-md border border-purple-500/20 shadow-xl hover:shadow-primary/20 transition-shadow duration-300 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}
              >
                <div className="md:w-1/2">
                  <div className="flex items-center mb-4">
                    <div className="p-3 bg-primary/10 rounded-full mr-4">
                      {service.icon}
                    </div>
                    <h2 className="text-3xl font-semibold text-primary-foreground">{service.title}</h2>
                  </div>
                  <p className="text-muted-foreground mb-6 text-lg leading-relaxed">{service.description}</p>
                  <ul className="space-y-2 mb-6">
                    {service.details.map((detail, i) => (
                      <li key={i} className="flex items-start">
                        <Zap size={18} className="text-green-400 mr-3 mt-1 flex-shrink-0" />
                        <span className="text-gray-300">{detail}</span>
                      </li>
                    ))}
                  </ul>
                  <Link to="/pricing">
                    <Button variant="outline" className="text-purple-300 border-purple-400 hover:bg-purple-400 hover:text-slate-900 transition-colors duration-300 group">
                      Explore Plans <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </div>
                <div className="md:w-1/2">
                  <img  
                    alt={service.title} 
                    className="w-full h-auto rounded-lg shadow-2xl object-cover aspect-video"
                   src="https://images.unsplash.com/photo-1675023112817-52b789fd2ef0" />
                </div>
              </motion.section>
            ))}
          </div>

          <motion.section
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="mt-20 text-center"
          >
            <h2 className="text-4xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-teal-400 via-cyan-500 to-sky-500">Ready to Begin Your Digital Legacy?</h2>
            <p className="text-lg text-purple-200 mb-8 max-w-xl mx-auto">
              Join Digital Heritage today and step into the future of personal data, knowledge, and connection.
            </p>
            <Link to="/login">
              <Button size="lg" className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white font-semibold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300">
                Get Started Now <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </motion.section>
        </div>
      );
    };

    export default ServicesPage;