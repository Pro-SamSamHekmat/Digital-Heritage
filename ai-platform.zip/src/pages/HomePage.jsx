import React from 'react';
    import { motion } from 'framer-motion';
    import { Brain, Users, Lock, Lightbulb, Layers, BarChart3, Target, CheckCircle, Cpu, HeartHandshake as Handshake, ShieldCheck, Zap, ArrowRight } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Link } from 'react-router-dom';

    const FeatureCard = ({ icon, title, description, delay }) => (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.5, delay }}
        className="bg-card p-6 rounded-xl shadow-lg hover:shadow-2xl hover:shadow-primary/30 transition-all duration-300 transform hover:-translate-y-1"
      >
        <div className="flex items-center mb-4">
          <div className="p-3 bg-primary/10 rounded-full mr-4 text-primary">
            {icon}
          </div>
          <h3 className="text-xl font-semibold text-primary-foreground">{title}</h3>
        </div>
        <p className="text-muted-foreground">{description}</p>
      </motion.div>
    );

    const TechCard = ({ icon, name, delay }) => (
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.4, delay }}
        className="flex flex-col items-center p-4 bg-secondary/20 rounded-lg shadow-md hover:bg-secondary/30 transition-colors duration-300"
      >
        <div className="p-3 text-primary mb-2">{icon}</div>
        <p className="text-sm font-medium text-primary-foreground">{name}</p>
      </motion.div>
    );

    const HomePage = () => {
      const features = [
        { icon: <Brain size={24} />, title: "Intelligent Digital Twin", description: "Create digital avatars with unique personality, voice and knowledge. Simulate deceased loved ones based on historical data. Automatic learning from user interests, behaviors and expertise." },
        { icon: <Lightbulb size={24} />, title: "Multidimensional Specialized Learning", description: "AI assistants in basic sciences, philosophy, art, and foreign languages with natural conversation." },
        { icon: <Lock size={24} />, title: "NFT-based Digital Identity", description: "Register exclusive ownership of AI data and models. Sell/rent personalized assistants. Transfer digital assets." },
        { icon: <Users size={24} />, title: "Secure Interactive Environment", description: "Expert forums, virtual events, and anonymous consultations with professionals." },
        { icon: <ShieldCheck size={24} />, title: "Privacy and Security", description: "Decentralized data storage (IPFS + Blockchain), advanced cryptography (ZKP), and full user control." },
      ];

      const technologies = [
        { icon: <Cpu size={32} />, name: "GPT-4, LoRA" },
        { icon: <Layers size={32} />, name: "Stable Diffusion" },
        { icon: <Zap size={32} />, name: "Whisper AI" },
        { icon: <Handshake size={32} />, name: "Ethereum/Polygon" },
        { icon: <BarChart3 size={32} />, name: "IPFS, Smart Contracts" },
        { icon: <Target size={32} />, name: "React, Node.js, GraphQL" },
        { icon: <CheckCircle size={32} />, name: "AES-256, ZKP, OAuth 2.0" },
      ];

      const monetization = [
        { title: "Monthly Subscription", description: "Access to premium features and enhanced capabilities." },
        { title: "NFT Marketplace", description: "Platform for selling and buying AI assistants and digital assets." },
        { title: "Transaction Fees", description: "Fees for expert advice, model rental, and premium interactions." },
        { title: "Enterprise Edition", description: "Tailored solutions for universities and businesses." },
      ];
      
      const targetAudience = [
        { name: "General Users", purpose: "To preserve memories and learn." },
        { name: "Professionals", purpose: "Providing services in a secure environment." },
        { name: "Organizations", purpose: "Training employees with digital twins." },
        { name: "Artists", purpose: "Creating new works inspired by historical styles." }
      ];

      return (
        <div className="container mx-auto px-4 py-12">
          <motion.section 
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center mb-20 pt-10"
          >
            <h1 className="text-5xl md:text-6xl font-extrabold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">
              Multidimensional AI Platform
            </h1>
            <p className="text-xl md:text-2xl text-purple-200 mb-4 max-w-3xl mx-auto">
              Deep Learning • Decentralized Identity • Intelligent Interaction
            </p>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="my-8 p-6 bg-white/5 backdrop-blur-sm rounded-xl shadow-2xl max-w-4xl mx-auto border border-purple-500/30"
            >
               <div className="relative w-full max-w-4xl mx-auto h-64 md:h-96 rounded-xl overflow-hidden shadow-2xl mb-8">
                  <img  
                    alt="Abstract representation of AI and human connection, futuristic digital art" 
                    className="absolute inset-0 w-full h-full object-cover opacity-70"
                   src="https://images.unsplash.com/photo-1677442136019-21780ecad995" />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent"></div>
                  <div className="absolute bottom-0 left-0 p-6 md:p-8">
                    <h2 className="text-2xl md:text-3xl font-semibold text-white">
                      👁️‍🗨️ Project Vision
                    </h2>
                  </div>
                </div>
              <p className="text-lg text-gray-300 leading-relaxed">
                The “Digital Heritage” project is an advanced AI platform that merges the boundaries of technology, emotions and knowledge. It empowers users to create digital versions of themselves or loved ones, benefit from expert AI advice, connect with a secure community, and manage data with decentralized digital ownership.
              </p>
              <Link to="/services">
                <Button size="lg" className="mt-8 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300">
                  Explore Our Services <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </motion.div>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.0 }}
              className="text-xl italic text-purple-300 mt-8"
            >
              “Preserving memories, expanding knowledge and empowering human connections through new technologies.”
            </motion.p>
          </motion.section>

          <motion.section 
            id="features" 
            className="mb-20"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            transition={{ staggerChildren: 0.2 }}
          >
            <h2 className="text-4xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-green-400 via-teal-500 to-cyan-500">✨ Key Features</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <FeatureCard key={index} icon={feature.icon} title={feature.title} description={feature.description} delay={index * 0.1} />
              ))}
            </div>
          </motion.section>

          <motion.section 
            id="technology" 
            className="mb-20"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            transition={{ staggerChildren: 0.1 }}
          >
            <h2 className="text-4xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-500">🛠️ Advanced Technologies</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-6">
              {technologies.map((tech, index) => (
                <TechCard key={index} icon={tech.icon} name={tech.name} delay={index * 0.05} />
              ))}
            </div>
          </motion.section>

          <motion.section 
            id="monetization" 
            className="mb-20"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            transition={{ staggerChildren: 0.2 }}
          >
            <h2 className="text-4xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500">📊 Monetization Model</h2>
            <div className="grid md:grid-cols-2 gap-8">
              {monetization.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.3 }}
                  transition={{ duration: 0.5, delay: index * 0.15 }}
                  className="bg-card p-6 rounded-xl shadow-lg hover:shadow-xl hover:shadow-yellow-500/20 transition-all duration-300 transform hover:-translate-y-1"
                >
                  <h3 className="text-xl font-semibold text-primary-foreground mb-2">{item.title}</h3>
                  <p className="text-muted-foreground">{item.description}</p>
                </motion.div>
              ))}
            </div>
             <div className="text-center mt-12">
                <Link to="/pricing">
                    <Button size="lg" variant="outline" className="text-yellow-400 border-yellow-500 hover:bg-yellow-500/10 hover:text-yellow-300 font-semibold py-3 px-8 rounded-lg shadow-lg transform hover:scale-105 transition-all duration-300">
                    View Pricing Plans <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                </Link>
            </div>
          </motion.section>
          
          <motion.section 
            id="target-audience" 
            className="mb-20"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.2 }}
            transition={{ staggerChildren: 0.2 }}
          >
            <h2 className="text-4xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-pink-500 via-rose-500 to-fuchsia-500">🌍 Target Audience</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {targetAudience.map((audience, index) => (
                <Card 
                  key={index} 
                  className="bg-gradient-to-br from-slate-800 to-slate-700 border-slate-600 shadow-lg hover:shadow-pink-500/30 transition-all duration-300 transform hover:scale-105 hover:-translate-y-1"
                >
                  <CardHeader>
                    <CardTitle className="text-xl font-semibold text-pink-300">{audience.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-400">{audience.purpose}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </motion.section>
        </div>
      );
    };

    export default HomePage;