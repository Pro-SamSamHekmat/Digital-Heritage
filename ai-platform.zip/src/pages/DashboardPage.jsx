import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
    import { Button } from '@/components/ui/button';
    import { User, Settings, Bell, Edit3, PlusCircle } from 'lucide-react';

    const StatCard = ({ title, value, icon, color }) => (
      <Card className={`bg-card/80 backdrop-blur-md border-${color}-500/50 shadow-lg hover:shadow-${color}-500/30 transition-shadow`}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
          {React.cloneElement(icon, { className: `h-5 w-5 text-${color}-400` })}
        </CardHeader>
        <CardContent>
          <div className={`text-2xl font-bold text-${color}-300`}>{value}</div>
          <p className="text-xs text-muted-foreground">+20.1% from last month</p>
        </CardContent>
      </Card>
    );

    const DashboardPage = () => {
      const userName = "Valued User"; // Placeholder, fetch from auth context later

      return (
        <div className="container mx-auto px-4 py-12">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <h1 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-red-500">
              Welcome back, {userName}!
            </h1>
            <p className="text-lg text-purple-200">Here's an overview of your Digital Heritage.</p>
          </motion.div>

          <motion.div 
            className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, staggerChildren: 0.1 }}
          >
            <StatCard title="Active Digital Twins" value="3" icon={<User />} color="purple" />
            <StatCard title="Knowledge Modules Accessed" value="12" icon={<Settings />} color="pink" />
            <StatCard title="Community Interactions" value="150" icon={<Bell />} color="teal" />
            <StatCard title="NFTs Owned" value="5" icon={<Edit3 />} color="yellow" />
          </motion.div>

          <motion.div 
            className="grid gap-6 md:grid-cols-1 lg:grid-cols-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, staggerChildren: 0.1 }}
          >
            <Card className="bg-card/70 backdrop-blur-md border-purple-500/30 shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl text-primary-foreground">Your Digital Twins</CardTitle>
                <CardDescription className="text-muted-foreground">Manage and interact with your created digital personas.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {['Personal Assistant', 'Grandmother\'s Legacy', 'Creative Writing Partner'].map((twin, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + index * 0.1 }}
                    className="flex items-center justify-between p-4 bg-secondary/30 rounded-lg hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex items-center space-x-3">
                      <User className="h-6 w-6 text-purple-400" />
                      <span className="font-medium text-gray-200">{twin}</span>
                    </div>
                    <Button variant="outline" size="sm" className="text-purple-300 border-purple-400 hover:bg-purple-400 hover:text-slate-900">
                      Manage
                    </Button>
                  </motion.div>
                ))}
                <Button className="w-full mt-4 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white">
                  <PlusCircle className="mr-2 h-5 w-5" /> Create New Digital Twin
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-card/70 backdrop-blur-md border-pink-500/30 shadow-xl">
              <CardHeader>
                <CardTitle className="text-2xl text-primary-foreground">Recent Activity</CardTitle>
                <CardDescription className="text-muted-foreground">Overview of your recent interactions and learning.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  "Accessed 'Quantum Physics Basics' module.",
                  "Interacted with 'Philosophical Debates' forum.",
                  "Updated 'Personal Assistant' digital twin.",
                  "Received a new message in 'Art History' community."
                ].map((activity, index) => (
                   <motion.div 
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + index * 0.1 }}
                    className="text-sm text-gray-300 p-3 bg-secondary/20 rounded-md"
                  >
                    {activity}
                  </motion.div>
                ))}
              </CardContent>
            </Card>
          </motion.div>
          
          <motion.div 
            className="mt-12 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
          >
            <img  
              alt="Stylized illustration of a futuristic dashboard interface" 
              className="w-full max-w-3xl mx-auto rounded-lg shadow-2xl opacity-80"
             src="https://images.unsplash.com/photo-1571677246347-5040036b95cc" />
          </motion.div>

        </div>
      );
    };

    export default DashboardPage;