import React from 'react';
    import { motion } from 'framer-motion';
    import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
    import { Input } from '@/components/ui/input';
    import { Button } from '@/components/ui/button';
    import { LifeBuoy, Search, MessageSquare, BookOpen, Users, ShieldCheck } from 'lucide-react';

    const faqData = [
      {
        value: "item-1",
        question: "What is a Digital Twin?",
        answer: "A Digital Twin on our platform is an AI-powered virtual representation of an individual. It can learn from data you provide (texts, voice, interests) to simulate personality, share knowledge, and even interact in a way that reflects the person it's based on. This can be used to preserve memories of loved ones, create personal assistants, or explore different facets of one's own identity."
      },
      {
        value: "item-2",
        question: "How is my data secured?",
        answer: "We prioritize your privacy and data security using multiple layers of protection. This includes options for decentralized storage on IPFS and blockchain, end-to-end encryption for communications, and advanced cryptographic methods like Zero-Knowledge Proofs for certain interactions. You have full control over your data, including access permissions and deletion."
      },
      {
        value: "item-3",
        question: "What are NFTs and how are they used?",
        answer: "NFTs (Non-Fungible Tokens) are unique digital certificates of ownership recorded on a blockchain. On Digital Heritage, you can mint your AI models, datasets, or even specific digital twin configurations as NFTs. This gives you true, verifiable ownership, and the ability to sell, rent, or transfer these digital assets in our marketplace or other compatible platforms."
      },
      {
        value: "item-4",
        question: "Can I use Digital Heritage for professional purposes?",
        answer: "Absolutely! Professionals can leverage Digital Heritage to provide services in a secure environment, create specialized AI assistants for their clients, or use digital twins for training and simulation. Our platform offers tools for expert forums, anonymous consultations, and creating tailored AI knowledge bases."
      },
      {
        value: "item-5",
        question: "How do I get started?",
        answer: "Getting started is easy! Simply sign up for an account. You can begin by exploring our free features, creating a basic digital twin, or browsing the community forums and learning modules. Our user-friendly interface will guide you through the process. For more advanced features, you can explore our subscription plans."
      }
    ];

    const helpCategories = [
        { name: "Getting Started", icon: <BookOpen size={24} />, description: "Guides on account creation, first steps, and platform navigation." },
        { name: "Digital Twins", icon: <Users size={24} />, description: "Detailed information on creating, training, and managing your digital personas." },
        { name: "Privacy & Security", icon: <ShieldCheck size={24} />, description: "Learn about our security measures, data control, and privacy settings." },
        { name: "NFTs & Marketplace", icon: <BookOpen size={24} />, description: "Understand how to mint, manage, and trade digital assets." },
    ];

    const HelpPage = () => {
      const [searchTerm, setSearchTerm] = React.useState('');

      const filteredFaqs = faqData.filter(faq => 
        faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
        faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
      );

      return (
        <div className="container mx-auto px-4 py-16">
          <motion.section
            initial={{ opacity: 0, y: -30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <LifeBuoy size={64} className="mx-auto mb-6 text-primary animate-pulse" />
            <h1 className="text-5xl md:text-6xl font-extrabold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-green-400 via-cyan-500 to-blue-500">
              Help Center
            </h1>
            <p className="text-xl text-purple-200 max-w-2xl mx-auto">
              Find answers to your questions, learn how to use our platform, and get support when you need it.
            </p>
          </motion.section>

          <motion.section 
            className="mb-12 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="relative">
              <Input 
                type="search" 
                placeholder="Search for help articles or FAQs..." 
                className="w-full p-4 pl-12 text-lg rounded-lg bg-card/70 border-purple-500/30 focus:ring-primary focus:border-primary"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-6 w-6 text-muted-foreground" />
            </div>
          </motion.section>
          
          <motion.section 
            className="mb-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, staggerChildren: 0.1 }}
          >
            <h2 className="text-3xl font-bold text-center mb-8 text-primary-foreground">Browse Help Topics</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {helpCategories.map((category, index) => (
                    <motion.div 
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true, amount: 0.3 }}
                        transition={{ duration: 0.5 }}
                    >
                        <div className="p-6 bg-card/70 backdrop-blur-md border border-purple-500/20 rounded-xl shadow-lg hover:shadow-primary/20 transition-shadow h-full text-center">
                            <div className="p-3 bg-primary/10 rounded-full w-16 h-16 mx-auto flex items-center justify-center mb-3 text-primary">
                                {category.icon}
                            </div>
                            <h3 className="text-xl font-semibold text-primary-foreground mb-2">{category.name}</h3>
                            <p className="text-muted-foreground text-sm">{category.description}</p>
                        </div>
                    </motion.div>
                ))}
            </div>
          </motion.section>


          <motion.section 
            className="mb-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-3xl font-bold text-center mb-8 text-primary-foreground">Frequently Asked Questions</h2>
            {filteredFaqs.length > 0 ? (
              <Accordion type="single" collapsible className="w-full max-w-3xl mx-auto space-y-4">
                {filteredFaqs.map((faq, index) => (
                  <motion.div
                    key={faq.value}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                  >
                    <AccordionItem value={faq.value} className="bg-card/70 backdrop-blur-md border border-purple-500/20 rounded-lg shadow-md">
                      <AccordionTrigger className="p-6 text-lg font-medium text-primary-foreground hover:no-underline hover:text-primary transition-colors">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="p-6 pt-0 text-base text-muted-foreground leading-relaxed">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  </motion.div>
                ))}
              </Accordion>
            ) : (
              <p className="text-center text-muted-foreground text-lg">No FAQs found matching your search term.</p>
            )}
          </motion.section>

          <motion.section 
            className="text-center p-8 bg-gradient-to-r from-purple-600/30 via-pink-600/30 to-red-600/30 rounded-xl shadow-2xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-white mb-4">Still Need Help?</h2>
            <p className="text-purple-200 mb-6 max-w-lg mx-auto">
              If you can't find what you're looking for, our support team is ready to assist you.
            </p>
            <Button variant="outline" size="lg" className="bg-transparent border-white text-white hover:bg-white hover:text-slate-900 transition-colors">
              <MessageSquare className="mr-2 h-5 w-5" /> Contact Support
            </Button>
          </motion.section>
        </div>
      );
    };

    export default HelpPage;