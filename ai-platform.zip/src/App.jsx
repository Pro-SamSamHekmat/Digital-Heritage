import React from 'react';
    import { BrowserRouter as Router, Routes, Route, Link, NavLink } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Toaster } from '@/components/ui/toaster';
    import { Button } from '@/components/ui/button';
    import HomePage from '@/pages/HomePage';
    import LoginPage from '@/pages/LoginPage';
    import DashboardPage from '@/pages/DashboardPage';
    import ServicesPage from '@/pages/ServicesPage';
    import PricingPage from '@/pages/PricingPage';
    import AboutPage from '@/pages/AboutPage';
    import HelpPage from '@/pages/HelpPage';
    import ChatWidget from '@/components/ChatWidget';
    import { LogIn, Home, Briefcase, DollarSign, Info, HelpCircle, UserCircle } from 'lucide-react';

    const navLinks = [
      { to: "/", label: "Home", icon: <Home size={18} /> },
      { to: "/services", label: "Services", icon: <Briefcase size={18} /> },
      { to: "/pricing", label: "Pricing", icon: <DollarSign size={18} /> },
      { to: "/about", label: "About Us", icon: <Info size={18} /> },
      { to: "/help", label: "Help", icon: <HelpCircle size={18} /> },
    ];

    const App = () => {
      const [isLoggedIn, setIsLoggedIn] = React.useState(false); 
      
      return (
        <Router>
          <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-gray-100 flex flex-col items-center">
            <Toaster />
            <header className="w-full py-4 px-4 md:px-8 sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md shadow-xl">
              <div className="container mx-auto flex justify-between items-center">
                <Link to="/" className="flex items-center space-x-2">
                  <motion.div
                    initial={{ rotate: 0 }}
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, ease: "linear", repeat: Infinity }}
                  >
                    <img  src="/favicon.svg" alt="Digital Heritage Logo" className="h-10 w-10" src="https://images.unsplash.com/photo-1692023707880-1b18d155520f" />
                  </motion.div>
                  <motion.h1 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5 }}
                    className="text-2xl md:text-3xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-500 to-red-500"
                  >
                    Digital Heritage
                  </motion.h1>
                </Link>
                <motion.nav
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="hidden md:flex space-x-2 items-center"
                >
                  {navLinks.map(link => (
                    <NavLink
                      key={link.to}
                      to={link.to}
                      className={({ isActive }) =>
                        `flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300 hover:bg-purple-500/20 ${
                          isActive ? 'text-purple-300 bg-purple-500/10' : 'text-gray-300 hover:text-purple-200'
                        }`
                      }
                    >
                      {link.icon}
                      <span>{link.label}</span>
                    </NavLink>
                  ))}
                   {isLoggedIn ? (
                    <NavLink
                      to="/dashboard"
                      className={({ isActive }) =>
                        `flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300 hover:bg-purple-500/20 ${
                          isActive ? 'text-purple-300 bg-purple-500/10' : 'text-gray-300 hover:text-purple-200'
                        }`
                      }
                    >
                      <UserCircle size={18} />
                      <span>Dashboard</span>
                    </NavLink>
                  ) : (
                    <NavLink
                      to="/login"
                      className={({ isActive }) =>
                        `flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-300 hover:bg-purple-500/20 ${
                          isActive ? 'text-purple-300 bg-purple-500/10' : 'text-gray-300 hover:text-purple-200'
                        }`
                      }
                    >
                      <LogIn size={18} />
                      <span>Login</span>
                    </NavLink>
                  )}
                </motion.nav>
                 <div className="md:hidden">
                  <Button variant="ghost" size="icon">
                    {/* Placeholder for mobile menu icon, e.g., Menu from lucide-react */}
                  </Button>
                </div>
              </div>
            </header>

            <main className="w-full flex-grow">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/login" element={<LoginPage setIsLoggedIn={setIsLoggedIn} />} />
                <Route path="/dashboard" element={isLoggedIn ? <DashboardPage /> : <LoginPage setIsLoggedIn={setIsLoggedIn} />} />
                <Route path="/services" element={<ServicesPage />} />
                <Route path="/pricing" element={<PricingPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/help" element={<HelpPage />} />
              </Routes>
            </main>
            
            <ChatWidget />

            <footer className="w-full py-8 bg-slate-900/90 border-t border-slate-700 mt-auto">
              <div className="container mx-auto text-center text-gray-400">
                <div className="flex justify-center space-x-6 mb-4">
                  <Link to="/about" className="hover:text-purple-300 transition-colors">About Us</Link>
                  <Link to="/services" className="hover:text-purple-300 transition-colors">Services</Link>
                  <Link to="/help" className="hover:text-purple-300 transition-colors">Help Center</Link>
                  <span className="cursor-pointer hover:text-purple-300 transition-colors">Privacy Policy</span>
                  <span className="cursor-pointer hover:text-purple-300 transition-colors">Terms of Service</span>
                </div>
                <p className="text-sm">&copy; {new Date().getFullYear()} Digital Heritage. All rights reserved.</p>
                <p className="text-xs mt-1">Preserving legacies, empowering connections.</p>
              </div>
            </footer>
          </div>
        </Router>
      );
    };

    export default App;