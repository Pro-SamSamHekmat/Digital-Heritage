import React, { useState } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { ScrollArea } from '@/components/ui/scroll-area';
    import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
    import { MessageSquare, Send, X, Bot } from 'lucide-react';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

    const ChatWidget = () => {
      const [isOpen, setIsOpen] = useState(false);
      const [messages, setMessages] = useState([
        { id: 1, text: "Hello! How can I help you today with Digital Heritage?", sender: 'bot' }
      ]);
      const [inputValue, setInputValue] = useState('');

      const handleSendMessage = () => {
        if (inputValue.trim() === '') return;
        const newMessage = { id: messages.length + 1, text: inputValue, sender: 'user' };
        const botResponse = { id: messages.length + 2, text: "Thanks for your message! A human agent will be with you shortly. (This is a simulated response)", sender: 'bot' };
        
        setMessages([...messages, newMessage, botResponse]);
        setInputValue('');
      };

      const toggleChat = () => setIsOpen(!isOpen);

      return (
        <>
          <motion.div
            className="fixed bottom-6 right-6 z-50"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20, delay: 1 }}
          >
            <Button
              onClick={toggleChat}
              size="lg"
              className="rounded-full p-4 shadow-xl bg-gradient-to-r from-primary to-pink-500 hover:from-primary/90 hover:to-pink-500/90 text-white w-16 h-16"
              aria-label="Open chat"
            >
              <MessageSquare size={32} />
            </Button>
          </motion.div>

          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogContent className="sm:max-w-[425px] bg-card/90 backdrop-blur-lg border-primary/50 text-foreground p-0">
              <DialogHeader className="p-6 pb-2 border-b border-border">
                <DialogTitle className="flex items-center text-xl">
                  <Bot size={28} className="mr-3 text-primary" />
                  Digital Heritage Support
                </DialogTitle>
                <DialogDescription>
                  Ask us anything about the platform.
                </DialogDescription>
              </DialogHeader>
              
              <ScrollArea className="h-[400px] p-6">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`flex items-end max-w-[75%] ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                        <Avatar className={`h-8 w-8 ${message.sender === 'user' ? 'ml-2' : 'mr-2'}`}>
                           <AvatarImage asChild>
                            <img  src={message.sender === 'bot' ? "/bot-avatar.png" : "/user-avatar.png"} alt={`${message.sender} avatar`} src="https://images.unsplash.com/photo-1684369176170-463e84248b70" />
                           </AvatarImage>
                          <AvatarFallback className="bg-primary/20 text-primary">
                            {message.sender === 'bot' ? 'B' : 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div
                          className={`p-3 rounded-lg ${
                            message.sender === 'user'
                              ? 'bg-primary text-primary-foreground rounded-br-none'
                              : 'bg-secondary text-secondary-foreground rounded-bl-none'
                          }`}
                        >
                          <p className="text-sm">{message.text}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </ScrollArea>
              
              <DialogFooter className="p-4 border-t border-border">
                <div className="flex w-full items-center space-x-2">
                  <Input
                    type="text"
                    placeholder="Type your message..."
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1 bg-input border-border focus:ring-primary"
                  />
                  <Button onClick={handleSendMessage} className="bg-primary hover:bg-primary/90">
                    <Send size={18} />
                  </Button>
                </div>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </>
      );
    };

    export default ChatWidget;